int reference_is_packed(git_reference *ref);
